﻿using Microsoft.AspNetCore.Mvc;
using Steam_1.Models;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Steam_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        // GET: api/<UsersController>
        [HttpGet]
        public IEnumerable<AppUser> Get()
        {
            return AppUser.Read();
        }

        // GET api/<UsersController>/5
        [HttpGet("{id}")]
        public AppUser Get(int id)
        {
            foreach(var user in AppUser.UsersList)
            {
                if(user.Id == id)
                {
                    return user;
                }
            }
            return null;
        }

        // POST api/<UsersController>
        [HttpPost]
        public string Post([FromBody] AppUser user)
        {
            bool result = AppUser.Insert(user);
            if (result)
            {
                return "User added successfully";
            }
            return "User with the same ID already exists";
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] AppUser user)
        {
            foreach (var existingUser in AppUser.UsersList)
            {
                if (existingUser.Email == user.Email)
                {
                    return BadRequest(new { message = "Email is already in use" });

                }
            }
            AppUser.UsersList.Add(user);
            return Ok(new { message = "User registered successfully" });
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] AppUser loginDetails)
        {
            if (loginDetails == null || string.IsNullOrEmpty(loginDetails.Email) || string.IsNullOrEmpty(loginDetails.Password))
            {
                return BadRequest(new { message = "Invalid data received" });
            }

            foreach (var user in AppUser.UsersList)
            {
                if (user.Email == loginDetails.Email && user.Password == loginDetails.Password)
                {
                    return Ok(new { message = "Login successful" });
                }
            }

            return Unauthorized(new { message = "Invalid email or password" });
        }



        // PUT api/<UsersController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<UsersController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
