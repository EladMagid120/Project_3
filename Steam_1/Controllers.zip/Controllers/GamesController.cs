﻿using Microsoft.AspNetCore.Mvc;
using Steam_1.Models;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Steam_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GamesController : ControllerBase
    {
        private static List<Game> MyGamesList = new List<Game>();

        // GET: api/<GamesController>
        [HttpGet]
        public IEnumerable<Game> Get()
        {
            return Game.Read();
        }

        // GET api/<GamesController>/5
        [HttpGet("{id}")]
        public Game Get(int id)
        {
            foreach (var game in Game.GamesList)
            {
                if (game.AppID == id)
                {
                    return game;
                }
            }
            return null;
        }

        [HttpGet("GetByPrice")]
        public IEnumerable<Game> GetByPrice(double price)
        {
            List<Game> filteredGames = new List<Game>();

            foreach (Game game in MyGamesList)
            {
                if (game.Price > price)
                {
                    filteredGames.Add(game);
                }
            }

            return filteredGames;
        }

        [HttpGet("SearchByRankScore/{rankScore}")]
        public IEnumerable<Game> GetByRankScore(int rankScore)
        {
            List<Game> filterByRankScore = new List<Game>();

            foreach (Game game in MyGamesList)
            {
                if(game.Score_rank > rankScore)
                {
                    filterByRankScore.Add(game);
                }
            }
            return filterByRankScore;
        }
        

        [HttpGet("mygames")]
        public IEnumerable<Game> GetMyGames()
        {
            return MyGamesList;
        }

        //private static List<Game> MyGamesList = new List<Game>();

        // POST api/Games/mygames
        [HttpPost("mygames")]
        public IActionResult AddToMyList([FromBody] Game game)
        {
            // בדוק אם המשחק כבר קיים ברשימה לפי AppID
            if (MyGamesList.Any(g => g.AppID == game.AppID))
            {
                return BadRequest(new { message = $"Game with the same AppID {game.AppID} already exists in your list" });
            }

            // הוסף את המשחק לרשימה
            MyGamesList.Add(game);
            return Ok(new { message = $"Game with AppID {game.AppID} added to the list" });
        }

        // PUT api/<GamesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {

        }

        [HttpDelete("mygames/{id}")]
        public IActionResult DeleteFromMyList(int id)
        {
            Game gameToRemove = MyGamesList.FirstOrDefault(g => g.AppID == id);

            if (gameToRemove == null)
            {
                return NotFound(new { message = $"Game with ID {id} does not exist in your list" });
            }

            MyGamesList.Remove(gameToRemove);
            return Ok(new { message = $"Game with ID {id} was successfully deleted from your list" });
        }


    }
}
